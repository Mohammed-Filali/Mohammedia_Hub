const mongoose = require('mongoose');

const productSchema = new mongoose.Schema({
    reference: { 
        type: String, 
        required: true, 
        unique: true 
    },
    designation: { 
        type: String, 
        required: true 
    },
    price: { 
        type: Number, 
        required: true 
    },
    qteStock: { 
        type: Number, 
        required: true,
        min: 0
    }
}, {
  timestamps: true
});

module.exports = mongoose.model('Product', productSchema);
