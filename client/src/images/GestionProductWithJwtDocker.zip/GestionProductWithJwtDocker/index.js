const express = require("express");
const app = express();


const connectDB = require("./config/db");
const auth = require('./middleware/auth');

require("dotenv").config();
connectDB();

app.use(express.json());
app.use('/api/users', require('./Controllers/User'));
app.use("/api/products", auth, require("./Controllers/Product"));



app.listen(3000, () => {
    console.log('Server running on port 3000');
});

