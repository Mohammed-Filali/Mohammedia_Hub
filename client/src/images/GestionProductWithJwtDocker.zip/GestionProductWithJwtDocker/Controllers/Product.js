const express = require('express');
const Product = require('../Models/Product');
const router = express.Router();


router.post('/', async (req, res) => {
  const { reference, designation, price, qteStock } = req.body;

  try {
    const product = new Product({ reference, designation, price, qteStock });
    await product.save();
    res.status(201).json(product);
  } catch (err) {
    res.status(400).json({ message: 'Error creating product', error: err });
  }
});


router.get('/', async (req, res) => {
  try {
    
    const products = await Product.find();
    res.status(200).json(products);
  } catch (err) {
    res.status(500).json({ message: 'Error fetching products', error: err });
  }
});


module.exports = router;
