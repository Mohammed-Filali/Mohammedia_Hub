const express = require("express");
const app = express();


const connectDB = require("./config/db");

require("dotenv").config();
connectDB();


app.use("/products", middleware, require("./Controllers/Product"));



app.listen(3000, () => {
    console.log('Server running on port 3000');
});

